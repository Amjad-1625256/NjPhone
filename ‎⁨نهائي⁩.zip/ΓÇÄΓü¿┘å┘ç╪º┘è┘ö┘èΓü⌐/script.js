let sales = [];  // جميع المبيعات
let totalSales = 0; // المجموع الكلي للمبيعات

// تحميل المبيعات من localStorage
function loadSales() {
    const savedSales = JSON.parse(localStorage.getItem('sales'));
    if (savedSales) {
        sales = savedSales;
        totalSales = sales.reduce((acc, sale) => acc + sale.total, 0);
        updateSalesTable();
        updateTotalAmount();
    }
}

// حفظ المبيعات في localStorage
function saveSales() {
    localStorage.setItem('sales', JSON.stringify(sales));
}

// إضافة مبيعات جديدة
document.getElementById('addSaleForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const product = document.getElementById('product').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);
    const total = quantity * price;
    const date = new Date().toLocaleDateString();

    if (product && quantity > 0 && price > 0) {
        sales.push({ product, quantity, price, total, date });
        totalSales += total;
        saveSales();
        updateSalesTable();
        updateTotalAmount();

        document.getElementById('product').value = '';
        document.getElementById('quantity').value = '';
        document.getElementById('price').value = '';
    } else {
        alert('يرجى التأكد من صحة المدخلات');
    }
});

// تحديث جدول المبيعات
function updateSalesTable() {
    const salesTable = document.getElementById('salesTable')?.getElementsByTagName('tbody')[0];
    if (!salesTable) return;

    salesTable.innerHTML = '';

    sales.forEach((sale, index) => {
        const row = salesTable.insertRow();
        row.innerHTML = `
            <td>${sale.product}</td>
            <td>${sale.quantity}</td>
            <td>${sale.price.toLocaleString()} د.ع</td>
            <td>${sale.total.toLocaleString()} د.ع</td>
            <td>${sale.date}</td>
            <td><button onclick="deleteSale(${index})">حذف</button></td>
        `;
    });
}

// تحديث المجموع الكلي
function updateTotalAmount() {
    const totalAmountElem = document.getElementById('totalAmountValue');
    if (totalAmountElem) {
        totalAmountElem.textContent = totalSales.toLocaleString();
    }
}

// حذف مبيعات
function deleteSale(index) {
    totalSales -= sales[index].total;
    sales.splice(index, 1);
    saveSales();
    updateSalesTable();
    updateTotalAmount();
}

// عرض مبيعات حسب الأيام في صفحة "مبيعات كل الأيام"
function displayAllSalesByDate(salesData = sales) {
    const allSalesContainer = document.getElementById('allSalesContainer');
    if (!allSalesContainer) return;

    allSalesContainer.innerHTML = '';

    const groupedSales = salesData.reduce((acc, sale) => {
        if (!acc[sale.date]) acc[sale.date] = [];
        acc[sale.date].push(sale);
        return acc;
    }, {});

    for (const date in groupedSales) {
        const dayDiv = document.createElement('div');
        dayDiv.classList.add('daily-sale');
        dayDiv.innerHTML = `<h3>مبيعات يوم ${date}</h3>`;
        
        const table = document.createElement('table');
        table.classList.add('sales-table');
        const tableBody = document.createElement('tbody');
        
        let dayTotal = 0;

        // عرض المبيعات لهذا اليوم وحساب المجموع
        groupedSales[date].forEach(sale => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${sale.product}</td>
                <td>${sale.quantity}</td>
                <td>${sale.price.toLocaleString()} د.ع</td>
                <td>${sale.total.toLocaleString()} د.ع</td>
                <td>${sale.date}</td>
            `;
            tableBody.appendChild(row);
            dayTotal += sale.total; // إضافة المبلغ الإجمالي لهذا اليوم
        });

        table.appendChild(tableBody);
        dayDiv.appendChild(table);

        // إضافة المجموع الكلي لهذا اليوم أسفل الجدول
        const totalRow = document.createElement('tr');
        totalRow.innerHTML = `
            <td colspan="3" style="text-align:right; font-weight: bold;">المجموع الكلي:</td>
            <td colspan="2" style="font-weight: bold;">${dayTotal.toLocaleString()} د.ع</td>
        `;
        tableBody.appendChild(totalRow);

        allSalesContainer.appendChild(dayDiv);

        // إضافة فاصل بين الأيام
        const separator = document.createElement('div');
        separator.classList.add('separator');
        allSalesContainer.appendChild(separator);
    }
}

// وظيفة البحث عن المبيعات حسب التاريخ
function searchSalesByDate() {
    const searchDate = document.getElementById('searchDate').value;
    if (!searchDate) {
        alert('يرجى إدخال تاريخ للبحث');
        return;
    }

    const searchDateFormatted = new Date(searchDate).toLocaleDateString();
    
    // تصفية المبيعات بناءً على التاريخ المدخل
    const filteredSales = sales.filter(sale => sale.date === searchDateFormatted);
    
    // عرض المبيعات المفلترة فقط
    displayAllSalesByDate(filteredSales);
}

// تحميل المبيعات عند تحميل الصفحة
window.onload = function() {
    loadSales();
    
    // إذا كانت الصفحة تحتوي على عنصر allSalesContainer، يعني أننا في صفحة all_sales.html
    if (document.getElementById('allSalesContainer')) {
        displayAllSalesByDate();
    }

    // ربط حدث البحث بزر البحث
    document.getElementById('searchButton').addEventListener('click', searchSalesByDate);
};